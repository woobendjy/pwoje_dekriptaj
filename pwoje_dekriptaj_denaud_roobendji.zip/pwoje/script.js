let meni, teksLan, teksKripte, dekriptaj, alfabe = 'abcdefghijklmnopqrstuvwxyz.,-!? ';
let soti = true, teksValid = true, kriptajValid = true;


function kripte(chenn){
    const kod = [];
    msg = '';
    for(let c = 0; c < chenn.length; c++){
        for(let alfa of alfabe){
            if(alfa === chenn[c]){
                kod.push(alfabe.indexOf(alfa));
            }
        }
    }
    msg = kod.join(".");
    return msg;
}

function dekripte(chenn){ 
    let chen = chenn.split("."), kle = '';
    for(let ch in chen){
        for(let alf in alfabe){
            if(parseInt(alf) === parseInt(chen[ch])){      
                kle += alfabe[alf];                
            }
        }     
    }
    return kle;
}

alert("Byenvini nan pwojè Dekriptaj lan !");

do{
    let mesaj = '';
    meni = prompt("Fè chwa de meni ou vle an : "+
    "\n1.- Kripte yon mesaj "+
    "\n2.- Dekripte yon mesaj "+
    "\n3.- Kite pwogram nan");
    switch(parseInt(meni)){
        case 1 : 
            do{
                teksLan = prompt("Antre mo ou vle kripte an la : "+
                "\nNB : Itilize karaktè sa yo sèlman ==> 'abcdefghijklmnopqrstuvwxyz.,-!? '");
                if(!teksLan){
                    alert("Ou pa antre anyen kòm mesaj !");
                    teksValid = false;
                }else if(teksLan.length >= 0 && teksLan.length < 2){
                    alert("Ou dwe met pou piti 2 karaktè nan tèks ou vle kripte !");
                    teksValid = false;
                }else{
                    for(let t of teksLan){
                        if('0123456789`~@#$%^&*()_+={}|\:;"<>/'.includes(t)){
                            alert('Tèks ou an pa dwe gen chif karaktè spesyal sa yo : "`~@#$%^&*()_+={}|\:;"<>/" (Sèlman "abcdefghijklmnopqrstuvwxyz.,-!? "');
                            teksValid = false;
                            break;
                        }else{
                            teksValid = true;
                        }
                    }
                }
                if(teksValid){                    
                    mesaj = kripte(teksLan.toLowerCase());
                    alert("Mesaj ou an kripte konsa : "+mesaj);
                }
            }while(!teksValid);
        break;
        case 2 : 
        do{
            teksKripte = prompt("Antre tèks ou vle dekripte an la : "+
            "\nItilize chif avèk pwen (.) sèlman pou'w antre tèks ou an sou fòma  : '0.11.14' ==> 'alo'");
            if(!teksKripte){
                alert("Ou pa antre anyen kòm mesaj kripte !");
                kriptajValid = false;
            }else if(teksKripte.length >= 0 && teksKripte.length < 2){
                alert("Ou dwe met pou piti 2 karaktè nan tèks w'ap dekripte a !");
                kriptajValid = false;
            }else{
                for(let t of teksKripte){
                    if('abcdefghijklmnopqrstuvwxyz!~`#$%^&*()_+-=[]\{}|;":<>?,/ '.includes(t)){
                        alert('Tèks ou an pa dwe gen ni chif ni karaktè spesyal ladanl : ');
                        kriptajValid = false;
                        break;
                    }else{
                        kriptajValid = true;
                    }
                }
            }
            if(kriptajValid){               
                dekriptaj = dekripte(teksKripte);
                alert("Mesaj kripte'w lan se : "+dekriptaj);
            }
        }while(!kriptajValid);
        break;
        case 3 : 
            alert("Ou chwazi kite pwogram nan ! A byento !");
            soti = false;
        break;
        default :
            alert("Ou chwazi yon meni ki pa nan entèfas pwogram nan. Re-eseye ankò !");
        break;
    }
}while(soti);


// let alfabe = 'abcdefghijklmnopqrstuvwxyz.,-!? ', mesaj = '', kle = '';
// const kod = [];

// function kripte(chenn){
//     // console.log(chenn.replace(/ /g,''));
//     for(let c = 0; c < chenn.length; c++){
//         for(let alfa of alfabe){
//             if(alfa === chenn[c]){
//                 kod.push(alfabe.indexOf(alfa));
//             }
//         }
//     }
//     let msg = kod.join(".");
//     return msg;
// }
// mesaj = kripte("Bonswa tt moun kijan nou ye");
// console.log(mesaj);

// function dekripte(chenn){
//     chen = chenn.split(".");
//     // console.log(chen[2]);
//     for(let ch in chen){
//         for(let alf in alfabe){
//             if(parseInt(alf) === parseInt(chen[ch])){
//                 kle += alfabe[alf];
//             }
//         }        
//     }

//     return kle;
// }
// dekriptaj = dekripte("0.11.14.31.17.14.14.1");
// console.log(dekriptaj);